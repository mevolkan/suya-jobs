<?php
/*
 * Template Name: Single Event
 * Template Post Type: event
 */
get_header();
if (have_posts()) {
    while (have_posts()) {
        the_post();
        ?>
        <div class="container main-content">
            <div class="event-single">
                <h1><?php the_title(); ?></h1>
               
                <!-- Event Details -->
                <div class="event-content">
                    <div>
                        <?php the_post_thumbnail('thumbnail'); ?>
                    </div>
                    
                    <!-- Event Metadata -->
                    <div class="event-meta">
                        <?php
                        // Function to check and display metadata
                        function display_event_meta($label, $meta_key) {
                            $value = get_post_meta(get_the_ID(), $meta_key, true);
                            if (!empty(trim($value))) {
                                ?>
                                <div>
                                    <strong><?php echo esc_html($label); ?>:</strong>
                                    <?php echo esc_html($value); ?>
                                </div>
                                <?php
                            }
                        }

                        // Display metadata fields conditionally
                        display_event_meta('Organizer', 'organizer');
                        display_event_meta('Location', 'location');
                        display_event_meta('Website', 'event_website');
                        display_event_meta('Online Link', 'event_online_link');
                        display_event_meta('Registration Link', 'event_registration_link');
                        ?>
                        <div class="event-time">
                            <div><?php echo esc_html( get_post_meta( get_the_ID(), 'event_date', true ) ); ?></div>
                            <div><?php echo esc_html( get_post_meta( get_the_ID(), 'event_time', true ) ); ?></div>
                            <div><?php echo esc_html( get_post_meta( get_the_ID(), 'event_end_time', true ) ); ?></div>
                            <div><?php echo esc_html( get_post_meta( get_the_ID(), 'event_end_time', true ) ); ?></div>
                            <div><?php echo esc_html( get_post_meta( get_the_ID(), 'all_day_event', true ) ); ?></div>
                        </div>
                    </div>

                    <!-- Event Content -->
                    <?php 
                    $content = get_the_content();
                    if (!empty(trim($content))) {
                        ?>
                        <div class="event-description">
                            <?php the_content(); ?>
                        </div>
                        <?php
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
    }
}
get_footer();
?>